<?php
pdo_query("DROP TABLE IF EXISTS `ims_weisrc_quickad_ad`;
DROP TABLE IF EXISTS `ims_weisrc_quickad_article`;
DROP TABLE IF EXISTS `ims_weisrc_quickad_fans`;
DROP TABLE IF EXISTS `ims_weisrc_quickad_order`;
DROP TABLE IF EXISTS `ims_weisrc_quickad_setting`;
DROP TABLE IF EXISTS `ims_weisrc_quickad_sn`;
");
